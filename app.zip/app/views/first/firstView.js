var http = require("http");
var frameModule = require("ui/frame");
function pageLoaded(args) {
  var page = args.object;
  http.getJSON("https://novemyazilim.com/xmltojson.php?url=https://www.wired.com/fees")
    .then(function (res) {
      var jsonArr = [];
      jsonArr.push(res.channel.item[0]);
      jsonArr.push(res.channel.item[1]);
      jsonArr.push(res.channel.item[2]);
      jsonArr.push(res.channel.item[3]);
      jsonArr.push(res.channel.item[4]);

      var words = jsonArr[0]["description"].toLowerCase().split(" ");
      var counts = {};
      var compare = 0;
      var mostFrequent;
      (function (array) {
        for (var i = 0, len = array.length; i < len; i++) {
          var word = array[i];

          if (counts[word] === undefined) {
            counts[word] = 1;
          } else {
            counts[word] = counts[word] + 1;
          }
          if (counts[word] > compare) {
            compare = counts[word];
            mostFrequent = words[i];
          }
        }
        return mostFrequent;
      })(words);
      

      jsonArr[0]["test"] = mostFrequent;
      page.bindingContext = { data: jsonArr };
    }, function (e) {
      console.log(e);
    });
}

function getInfo(args) {
  var navigationEntry = {
    moduleName: "views/second/secondView",
    context: { info: args.view.bindingContext }
  }
  frameModule.topmost().navigate(navigationEntry);
}

exports.pageLoaded = pageLoaded;
exports.getInfo = getInfo;
