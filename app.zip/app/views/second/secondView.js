var utilityModule = require("utils/utils");
const request = require("tns-core-modules/http");

var querystring = require('querystring');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

var gotData;

function pageLoaded(args) {
  var page = args.object;
  gotData = page.navigationContext.info;
  page.bindingContext = { passedData: gotData };
}

function openLink() {
  utilityModule.openUrl(gotData.link);
}

var makeTranslateRequest = function (token) {
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.open("GET", "http://api.microsofttranslator.com/v2/Http.svc/Translate?from=en&to=ru&text=Good", true);
  xmlhttp.setRequestHeader('Authorization', 'Bearer ' + token);
  xmlhttp.onreadystatechange = function () {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      console.log(xmlhttp.responseText);
    }
  }
  /*
 var request = require('request');
 request('http://www.google.com', function (error, response, body) {
   if (!error && response.statusCode == 200) {
     console.log(body); // Print the google web page.
   }
 });*/
  xmlhttp.send();
}

/**
 * Get token and make translate request in a callback
 */
var requestOpts = querystring.stringify({
  client_id: 'Subtitles',
  client_secret: '_~o~wO9~51UZQ2Borja-JD~uiBOliYL0X_',
  scope: 'http://api.microsofttranslator.com',
  grant_type: 'client_credentials'
});

request.post({
  encoding: 'utf8',
  url: "https://datamarket.accesscontrol.windows.net/v2/OAuth2-13",
  body: requestOpts
}, function (err, res, body) {
  var token = JSON.parse(body).access_token;
  makeTranslateRequest(token);
});

exports.pageLoaded = pageLoaded;
exports.openLink = openLink;
